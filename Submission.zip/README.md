# Directory Structure

Setup the following directory structure
```
./
--data
	--training.csv (The input file)
	--test.csv (The images to be labeled)
--images
```
Add the training and test images in images folder(no different folders should be made).

## Requirements
```
	$ sudo apt install python3-opencv
	$ pip3 install -r requirements.txt
```

## Run in the following order
```
	$ git clone https://github.com/tensorflow/models.git 
	$ cp -r models/research/object_detection ./
```
Follow the installation instructions [here](https://github.com/tensorflow/models/blob/master/research/object_detection/g3doc/installation.md).
	
```
	# In tensorflow/models/research
	$ export PYTHONPATH=$PYTHONPATH:`pwd`:`pwd`/slim 

	$ python3 script1.py

	$ python3 script2.py

	$ python generate_tfrecord.py --csv_input=data/train_labels.csv  --output_path=data/train.record

	$ python generate_tfrecord.py --csv_input=data/test_labels.csv  --output_path=data/test.record

	$ bash train.sh

	$ bash export.sh

	$ python3 object_localisation.py
```

The final csv file can be located in /data/test_labeled.csv

To run the final code, download and extract [this](https://drive.google.com/open?id=1OPSS5arbySQkT8DZD2ZIFdan3meM0Bs2)
