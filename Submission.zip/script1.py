##################Preprocess csv file######################
import cv2
import numpy as np
import pandas as pd

df = pd.read_csv('./data/training.csv')
df.rename(columns={'image_name': 'filename'}, inplace=True)
n = len(df)

label = ['object']*n
for i in range(n):
	print(str(i)+'/'+str(n))
	img_name = df.loc[i, 'filename']
	try:
		img = cv2.imread("./images/"+str(img_name))
		height[i], width[i] = img.shape[:2]
	except:
		pass
df.insert(1, 'width', width)
df.insert(2, 'height', height)
df.insert(3, 'class', label)
df.to_csv('./data/train_labels.csv', index=False)